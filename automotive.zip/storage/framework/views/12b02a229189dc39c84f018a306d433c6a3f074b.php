<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <!-- BEGIN INVOICE -->
        <div class="col-xs-12">
            <div class="grid invoice">
                <div class="grid-body">
                    <div class="invoice-title">
                        <div class="row">
                            <div class="col-xs-12">
                                <img src="<?php echo e(asset('logo.png')); ?>" alt="" height="35">
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-xs-12">
                                <h2>invoice<br>
                                    <span class="small"><?php echo e($order->code); ?></span></h2>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-xs-6">
                            <address>
                                <strong>Billed To:</strong><br>
                                <?php echo e($customer->name); ?> - <?php echo e($customer->email); ?><br>
                                <?php echo e($address->city); ?>,
                                <?php echo e($address->state); ?>,
                                <?php echo e($address->country->name); ?><br>
                                
                            </address>
                        </div>
                        <div class="col-xs-6">
                            <address>
                                <strong>From:</strong><br>
                                <?php echo e($owner->name); ?> - <?php echo e($owner->email); ?><br>
                                
                                
                            </address>
                        </div>
                        
                    </div>
                    <div class="row">
                        
                        <div class="col-xs-6 text-right">
                            <address>
                                <strong>Order Date:</strong><br>
                                <?php echo e($order->created_at->format('d M,Y H:i:s')); ?>

                            </address>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <h3>ORDER SUMMARY</h3>
                            <div class="table-responsive">
                                <table class="table table-bordered" border="1px" style="width:100%">
                                    <thead>
                                        <tr class="line">
                                            <td><strong>#</strong></td>
                                            <td class="text-center"><strong>Product</strong></td>
                                            <td class="text-center"><strong>Sold</strong></td>
                                            <td class="text-right"><strong>RATE</strong></td>
                                            <td class="text-right"><strong>SUBTOTAL</strong></td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>

                                                <?php echo e($car_model->brand); ?>, <?php echo e($car_model->model); ?>,
                                                , <?php echo e($car_model->vehicle_type); ?>, <?php echo e($car_model->year); ?><br />
                                                <?php echo e($car->Vehicle_identification_number); ?><br /><?php echo e($car->vehicle_registration); ?><br />
                                                <?php echo e($car->mileage); ?> , <?php echo e($car->vehicle_gear_box_type); ?>


                                            </td>
                                            <td class="text-center">
                                                <?php echo e($order->currency); ?><?php echo e(number_format($order->price /100, 2)); ?></td>
                                            <td class="text-center">
                                                <?php echo e($order->currency); ?><?php echo e(number_format($order->propose_price/100, 2)); ?></td>
                                            <td class="text-right">
                                                <?php echo e($order->currency); ?><?php echo e(number_format($order->propose_price/100, 2)); ?></td>
                                        </tr>


                                        <tr>
                                            <td colspan="3"></td>
                                            <td class="text-right"><strong>Taxes</strong></td>
                                            <td class="text-right"><strong>N/A</strong></td>
                                        </tr>
                                        <tr>
                                            <td colspan="3">
                                            </td>
                                            <td class="text-right"><strong>Balance</strong></td>
                                            <td class="text-right">
                                                <strong><?php echo e($order->currency); ?><?php echo e(number_format(($order->price/100) - ($order->propose_price/100), 2)); ?></strong>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3">
                                            </td>
                                            <td class="text-right"><strong>Total</strong></td>
                                            <td class="text-right">
                                                <strong><?php echo e($order->currency); ?><?php echo e(number_format($order->propose_price /100, 2)); ?></strong>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <img src="<?php echo e(asset($car->cover_image)); ?>" alt="car cver image">
                    <div class="row">
                        <div class="col-md-6 ">
                            
                            View Order
                            
                        </div>
                        <div class="col-md-6 text-right identity">
                            Thanks,<br>
                            <?php echo e(config('app.name')); ?>, Business Team
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END INVOICE -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('paymentcss'); ?>
<style>
    body {
        margin-top: 20px;
        background: #eee;
    }

    .invoice {
        padding: 30px;
    }

    .invoice h2 {
        margin-top: 0px;
        line-height: 0.8em;
    }

    .invoice .small {
        font-weight: 300;
    }

    .invoice hr {
        margin-top: 10px;
        border-color: #ddd;
    }

    .invoice .table tr.line {
        border-bottom: 1px solid #ccc;
    }

    .invoice .table td {
        border: none;
    }

    .invoice .identity {
        margin-top: 10px;
        font-size: 1.1em;
        font-weight: 300;
    }

    .invoice .identity strong {
        font-weight: 600;
    }


    .grid {
        position: relative;
        width: 100%;
        background: #fff;
        color: #666666;
        border-radius: 2px;
        margin-bottom: 25px;
        box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.1);
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-mail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel\automotive\resources\views/mail/order.blade.php ENDPATH**/ ?>