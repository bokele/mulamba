<div class="table">
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</div>
<?php /**PATH C:\wamp64\www\laravel\automotive\resources\views/vendor/mail/html/table.blade.php ENDPATH**/ ?>