<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 0.1.1
    </div>
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> &nbsp;<a href="http://bkservices.com">BKServices</a>.</strong> All rights
    reserved.
</footer>
<?php /**PATH C:\wamp64\www\laravel\automotive\resources\views/seller/includes/footer.blade.php ENDPATH**/ ?>