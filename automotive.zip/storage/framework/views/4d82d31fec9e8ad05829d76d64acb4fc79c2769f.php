<section id="hero">
    <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">

        <div class="carousel-inner" role="listbox">

            <!-- Slide 1 -->
            <div class="carousel-item active"
                style="background-image: url(<?php echo e(asset('assets/img/slide/slide-1.jpg')); ?>);">
                <div class="carousel-container">
                    <div class="carousel-content animate__animated animate__fadeInUp">
                        <h2>Welcome to <span>Flattern</span></h2>
                        <p>Ut velit est quam dolor ad a aliquid qui aliquid. Sequi ea ut et est quaerat sequi nihil
                            ut aliquam. Occaecati alias dolorem mollitia ut. Similique ea voluptatem. Esse
                            doloremque accusamus repellendus deleniti vel. Minus et tempore modi architecto.</p>
                        <div class="text-center"><a href="" class="btn-get-started">Read More</a></div>
                    </div>
                </div>
            </div>

            <!-- Slide 2 -->
            <div class="carousel-item" style="background-image: url(<?php echo e(asset('assets/img/slide/slide-2.jpg')); ?>);">
                <div class="carousel-container">
                    <div class="carousel-content animate__animated animate__fadeInUp">
                        <h2>Lorem Ipsum Dolor</h2>
                        <p>Ut velit est quam dolor ad a aliquid qui aliquid. Sequi ea ut et est quaerat sequi nihil
                            ut aliquam. Occaecati alias dolorem mollitia ut. Similique ea voluptatem. Esse
                            doloremque accusamus repellendus deleniti vel. Minus et tempore modi architecto.</p>
                        <div class="text-center"><a href="" class="btn-get-started">Read More</a></div>
                    </div>
                </div>
            </div>

            <!-- Slide 3 -->
            <div class="carousel-item" style="background-image: url(<?php echo e(asset('assets/img/slide/slide-3.jpg')); ?>);">
                <div class="carousel-container">
                    <div class="carousel-content animate__animated animate__fadeInUp">
                        <h2>Sequi ea ut et est quaerat</h2>
                        <p>Ut velit est quam dolor ad a aliquid qui aliquid. Sequi ea ut et est quaerat sequi nihil
                            ut aliquam. Occaecati alias dolorem mollitia ut. Similique ea voluptatem. Esse
                            doloremque accusamus repellendus deleniti vel. Minus et tempore modi architecto.</p>
                        <div class="text-center"><a href="#" class="btn-get-started">Read More</a></div>
                    </div>
                </div>
            </div>

        </div>

        <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon bx bx-left-arrow" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>

        <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon bx bx-right-arrow" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>

        <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

    </div>
</section>
<?php /**PATH C:\wamp64\www\laravel\automotive\resources\views/includes/hero.blade.php ENDPATH**/ ?>