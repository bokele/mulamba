<?php $__env->startComponent('mail::message'); ?>
You are order has been aprove, you can now go to you finance section -> order and make the payment


<?php $__env->startComponent('mail::button', ['url' => $url]); ?>
Click here for payment
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>



<?php $__env->startComponent('mail::table'); ?>

<h3>ORDER SUMMARY</h3>


| Laravel | Sold | Paid |SUBTOTAL |
| ------------- |:-------------:| --------:|:-------------:|

| <?php echo e($car_model->brand); ?>, <?php echo e($car_model->model); ?>,
,<?php echo e($car_model->vehicle_type); ?>, <?php echo e($car_model->year); ?>

<?php echo e($car->Vehicle_identification_number); ?>

<?php echo e($car->vehicle_registration); ?>

<?php echo e($car->mileage); ?> , <?php echo e($car->vehicle_gear_box_type); ?> | <?php echo e($order->currency); ?><?php echo e(number_format($order->price /100, 2)); ?> |
<?php echo e($order->currency); ?><?php echo e(number_format($order->propose_price/100, 2)); ?>

|<?php echo e($order->currency); ?><?php echo e(number_format($order->propose_price/100, 2)); ?>|
| | | |Taxes: N/A|
| | | |Balance: <?php echo e($order->currency); ?><?php echo e(number_format(($order->price/100) - ($order->propose_price/100), 2)); ?>|
| | | |Total:<?php echo e($order->currency); ?><?php echo e(number_format($order->propose_price /100, 2)); ?>|




<?php if (isset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906)): ?>
<?php $component = $__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906; ?>
<?php unset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>, Business Team
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\laravel\automotive\resources\views/mail/approve.blade.php ENDPATH**/ ?>