<?php $__env->startSection('page-title'); ?>
Boutiques | Order | Success

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-subtitle'); ?>
Order Fail

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title-link'); ?>
<li><a href="#">boutiques</a></li>

<li>Fail</li>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="alert alert-info" role="alert">
    <h4 class="alert-heading">Informtion!</h4>

    <p><?php echo e($message); ?></p>


    <hr>
    <p class="mb-0">
        Your will receive a email when your propose price is approve For the payment


    </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel\automotive\resources\views/pages/order/fail.blade.php ENDPATH**/ ?>