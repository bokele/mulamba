<form class="form-horizontal" id="attachePhotoProfilForm" action="<?php echo e(route('user.profile.picture')); ?>" method="post"
    enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <fieldset>
        <legend>Profile picture</legend>
        <div id="phototProfil"><img id="preview_img" src="<?php echo e(asset(Auth::user()->profile_photo_path)); ?>" class=""
                width="200" height="150" /></div>
        <div class="form-group">
            <label for="profile_image" class="col-sm-4 control-label">Photo du profil :
            </label>
            <div class="col-sm-7">
                <!-- the avatar markup -->
                <div class="form-group">
                    <input type="file" name="profil_picture"
                        class="custom-file-input <?php $__errorArgs = ['profil_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="profile_image"
                        onchange="loadPreview(this);">
                    <label class="custom-file-label" for="customFile">Choose your profile
                        picture</label>
                    <?php $__errorArgs = ['profil_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


            </div>
        </div> <!-- /form-group-->

        <div class="modal-footer removeBrandFooter">
            <input type="hidden" name="user_id" id="user_id" value="" />
            <button type="submit" class="btn btn-primary btn-block" id="createPhotoBtn" data-loading-text="Loading..."
                autocomplete="off"> <i class="icofont-save"></i>
                Save</button>
        </div>
    </fieldset>

</form>
<?php /**PATH C:\wamp64\www\laravel\automotive\resources\views/profile/picture.blade.php ENDPATH**/ ?>