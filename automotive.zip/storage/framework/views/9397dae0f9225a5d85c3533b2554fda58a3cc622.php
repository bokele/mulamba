<?php $__env->startSection('page-title'); ?>
Boutiques | Cars |

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-subtitle'); ?>
Cars

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title-link'); ?>
<li>boutiques</li>
<li>car</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="section-title" data-aos="fade-up">
    <h2 class="font-weight-bold text-uppercase text-orange"><strong>Car for Sale and Let</strong></h2>
</div>
<div class="col-md-12">

    <div class="row" id="boutique-car">

        <?php echo $__env->make('pages.car.car_pagination_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<script type='text/javascript'>
    $(document).ready(function(){

$(document).on('click', '.pagination a', function(event){
event.preventDefault();
var page = $(this).attr('href').split('page=')[1];
fetch_data(page);
});

function fetch_data(page)
{
$.ajax({
url:"/boutique/car/data?page="+page,
success:function(data)
{
$('#boutique-car').html(data);
}
});
}

});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel\automotive\resources\views/pages/car/car.blade.php ENDPATH**/ ?>