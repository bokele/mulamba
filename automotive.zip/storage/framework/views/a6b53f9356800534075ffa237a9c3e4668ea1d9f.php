
<header id="header">
    <div class="container d-flex">

        <div class="logo mr-auto clearfix">
            
            <!-- Uncomment below if you prefer to use an image logo -->
            <a href="/">
                <img src="<?php echo e(asset('logo.png')); ?>" alt="mulamba logo" class="img-fluid  float-left" />
                <h1 class="font-weight-bolder text-purple ml-2"><?php echo e(config('app.name', 'Laravel')); ?></h1>
            </a>
        </div>

        <nav class="nav-menu d-none d-lg-block">
            <ul>
                <li><a href="/">Home</a></li>
                
                <li class="drop-down"><a href="">Boutiques</a>
                    <ul>
                        <li><a href="<?php echo e(route('car.get')); ?>">Cars</a></li>

                        <li><a href="#">Houses coming soon</a></li>
                        <li><a href="#">Estates coming soon</a></li>

                    </ul>
                </li>
                <li><a href="<?php echo e(route('about')); ?>">About</a></li>
                <li><a href="<?php echo e(route('services')); ?>">Services</a></li>
                <li><a href="<?php echo e(route('pricing')); ?>">Pricing</a></li>
                <li><a href="blog.html">Partner</a></li>

                <li><a href="contact.html">Contact</a></li>





                <?php if(Route::has('login')): ?>

                <?php if(auth()->guard()->check()): ?>
                <li> <a href="<?php echo e(url('/home')); ?>" class="login btn btn-outline-purple btn-md ml-2 mr-2 mt-2"
                        role="button" aria-pressed="true">Dashbord</a></li>

                <?php else: ?>
                <li> <a href="<?php echo e(route('login')); ?>" class="login btn btn-outline-orange btn-md ml-2 mr-2 mt-2"
                        role="button" aria-pressed="true">Login</a></li>

                <?php if(Route::has('register')): ?>
                <li> <a href="<?php echo e(route('register')); ?>" class="register btn btn-purple btn-md active ml-2 mr-2 mt-2 "
                        role="button" aria-pressed="true">Register</a></li>
                <?php endif; ?>
                <?php endif; ?>
            </ul>
        </nav><!-- .nav-menu -->
        <?php endif; ?>
    </div>
</header>
<?php /**PATH C:\wamp64\www\laravel\automotive\resources\views/includes/headerbar.blade.php ENDPATH**/ ?>