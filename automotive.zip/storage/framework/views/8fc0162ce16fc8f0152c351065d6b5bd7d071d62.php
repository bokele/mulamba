<?php echo e($slot); ?>

<?php /**PATH C:\wamp64\www\laravel\automotive\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/table.blade.php ENDPATH**/ ?>