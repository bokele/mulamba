<?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-4 mb-3">
    <div class="card h-100">
        <img src="<?php echo e(asset($row->cover_image)); ?>" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title text-center font-weight-bold text-uppercase text-orange">
                <?php echo e($row->brand); ?></h5>
            <h5 class="card-title text-center font-weight-bold text-uppercase text-success">
                <?php echo e($row->status); ?></h5>
            

            <p class="card-text ">
                
                <h5 class="text-orange font-weight-bold text-center">Price:<?php echo e(number_format($row->price/100,2)); ?></h5>
            </p>
            <div class="card-body">

                <br />Model :<?php echo e($row->model); ?>


                <br />Gear box type :<?php echo e($row->vehicle_gear_box_type); ?>

                <br /> Registration:<?php echo e($row->vehicle_registration); ?>

                <br /> Seat count :<?php echo e($row->vehicle_seat_count); ?>

                <br /> Door count :<?php echo e($row->vehicle_door_count); ?>

                <br />Mileage :<?php echo e($row->mileage); ?>

                <br />Country:<?php echo e($row->country_name); ?>


            </div>
            <a href="/boutiques/car/<?php echo e($row->id); ?>/detail" class="btn btn-purple">More info</a>
            <?php if($row->status == 'sale'): ?>
            <a href="/boutiques/car/<?php echo e($row->id); ?>/propose-price" class="btn btn-outline-orange">Buy
                Now</a>
            <?php elseif($row->status == 'rent'): ?>

            <a href="/boutiques/car/<?php echo e($row->id); ?>/rental" class="btn btn-outline-orange">Let
                Now</a>
            <a href="/boutiques/car/<?php echo e($row->id); ?>/booking" class="btn btn-info">Booking
            </a>

            <?php endif; ?>

        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $cars->links(); ?>

<?php /**PATH C:\wamp64\www\laravel\automotive\resources\views/pages/car/car_pagination_data.blade.php ENDPATH**/ ?>