<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Rental;
use Faker\Generator as Faker;

$factory->define(Rental::class, function (Faker $faker) {
    return [
        //
    ];
});
