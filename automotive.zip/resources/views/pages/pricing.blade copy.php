@extends('layouts.layout')

@section('page-title')
Pricing |

@endsection
@section('page-subtitle')
Pricing

@endsection
@section('title-link')
<li>Pricing</li>

@endsection
@section('content')



@endsection

@section('javascript')

@endsection
