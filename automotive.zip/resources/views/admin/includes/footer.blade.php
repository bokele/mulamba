<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 0.1.1
    </div>
    <strong>Copyright &copy; {{ date('Y')}} &nbsp;<a href="http://bkservices.com">BKServices</a>.</strong> All rights
    reserved.
</footer>
